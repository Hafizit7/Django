a = 10
b = 5
t = a & b
print(t)