#####     Iist

# my_list = {}

# student = ['Hafizul Islam', 918784, 'Computer','Group-A']

# student[1] = 918785
# student.extend(['barguna polytechnic inatitute barguna','Barguna Sadopr'])
# student.insert(1,'patwary')

# print(student)

##Tuple

# studetn = ('Hafizul Islam', 'Roll 918784','barguna polytechnich institute')
# studetn[2] = 'Dhaka'
# print(studetn)

###Set

# why = {'Md Hafizul Islam', 'Md Hafizul Islam', 'Hafizul Islam', 'Md Hafizul'}

# print(why)


student = {

    'name':'Hafiul islam', 'Deparment':'Computer', 'Roll':918784,
}
student['name'] = 'Rabbani'
print(student['name'])