# 

# english = 105

# if english >= 80 and english <=100 :
#     print('A+')
# elif english >= 70 and english <=79:
#     print('A')
# elif english >= 60 and english <=69:
#     print('A-')
# elif english >=50 and english <=59:
#     print('B')
# elif english >= 40 and english <=49:
#     print('C')
# elif english >= 33 and english <=39:
#     print('D')
# elif english >= 100:
#     print('Error')

# else:
#     print('faile')

# a ='G'

# if a=='A' and 'E' and 'I' and 'O' and 'U':
#     print('Vowel')
# else:
#     print('Cosonant')

 




