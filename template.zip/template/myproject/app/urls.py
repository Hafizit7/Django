from django.urls import path
from .views import index,about,contact,pricing,protfolio,protfolio_detilse,team,services

urlpatterns = [
    path('', index, name='Index'),
    path('about-us', about, name='About'),
    path('contact-us', contact, name='Contact'),
    path('princing-us', pricing, name='Princing'),
    path('portfolio-us', protfolio, name='Portfolio'),
    path('team-us', team, name='Team'),
    path('portfolio_details', protfolio_detilse, name='portfoliodetailse'),
    path('service', services, name='services')

]
